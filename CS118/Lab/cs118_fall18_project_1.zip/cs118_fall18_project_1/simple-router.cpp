/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/**
 * Copyright (c) 2017 Alexander Afanasyev
 *
 * This program is free software: you can redistribute it and/or modify it under the terms of
 * the GNU General Public License as published by the Free Software Foundation, either version
 * 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.ˆ
 *
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 */

#include "simple-router.hpp"
#include "core/utils.hpp"

#include <fstream>

namespace simple_router {
    
    //////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////
    // IMPLEMENT THIS METHOD
    void
    SimpleRouter::errorExit(std::string error_msg){
        std::cerr << error_msg << std::endl;
        return;
    }
    
    void
    SimpleRouter::handlePacket(const Buffer& packet, const std::string& inIface)
    {
        std::cerr << "Got packet of size " << packet.size() << " on interface " << inIface << std::endl;
        
        // Find input network interface
        const Interface* iface = findIfaceByName(inIface);
        
        // Drop if packet is unknown
        if (iface == nullptr) {
            errorExit("Received packet, but interface is unknown, ignoring");
        }
        
        std::cerr << getRoutingTable() << std::endl;
        
        // FILL THIS IN

        // Read ethernet header
        ethernet_hdr eth_hdr;
        memcpy(&eth_hdr, packet.data(), sizeof(ethernet_hdr));
        
        // Get MAC address of packet
        std::string packet_addr = macToString(packet);

        // TODO: Check Accuracy of IF
        if ((packet_addr != macToString(iface->addr)) && (packet_addr != "FF:FF:FF:FF:FF:FF") && (packet_addr != "ff:ff:ff:ff:ff:ff")) {
            errorExit("ERROR: Packet not destined for router, ignoring");
        }
        
        // Check eth_type field using ethertype() from utils.cpp
        uint16_t eth_type = ethertype((const uint8_t*)packet.data());
        
        if(eth_type == ethertype_arp){
            std::cerr << "NOTE: Handling ARP packet" << std::endl;
            handleArpPacket(packet, iface);
        }
        else if(eth_type == ethertype_ip){
            std::cerr << "NOTE: Handling IPv4 packet" << std::endl;
            handleIpPacket(packet, iface);
        }
        else{
            errorExit("ERROR: Packet is not of type ARP or IPv4, ignoring");
        }
    
    } // End handlePacket()
    
    void
    SimpleRouter::handleIpPacket(const Buffer& packet, const Interface* iface){
        
        // Get the packet
        Buffer ip_packet(packet);
        
        // Get pointer to the IP header
        ip_hdr* ip_header = (ip_hdr*)(ip_packet.data() + sizeof(ethernet_hdr));
        
        // Get the checksum for the ip_header
        uint16_t checksum = ip_header->ip_sum;
        ip_header->ip_sum = 0; // TODO: Why are we setting this to 0
        
        // Verify that minimum length of IP packet is met
        // Minimum allowed size of IP packet is the size of its header
        // Packet should be a minimum size of the ethernet + ip header sizes
        if ((packet.size() < (sizeof(ethernet_hdr) + sizeof(ip_hdr)))) {
            errorExit("ERROR: IP packet does not mean minimum length requirements");
        }
        else if((ip_header->ip_len < sizeof(ip_hdr))){
            errorExit("ERROR: IP packet does not mean minimum length requirements");
        }
        
        // Verify checksums
        if (checksum != cksum(ip_header, sizeof(ip_hdr))) {
            errorExit("ERROR: IP packet has an invalid checksum");
        }
        
        // TODO: What
        // For each hop, decrement TTL by 1
        ip_header->ip_ttl -= - 1;
        
        // Check that TTL > 0
        if (ip_header->ip_ttl <= 0) {
            errorExit("ERROR: IP packet has exceeded Time To Live");
        }
        
        // For each hop, recompute checksum
        ip_header->ip_sum = 0;
        ip_header->ip_sum = cksum(ip_header, sizeof(ip_hdr));
        
        
        // If packet was destined to router, discard packet
        // Check all the interfaces
        std::set<Interface>::const_iterator ifaceIt = m_ifaces.begin();
        while(ifaceIt != m_ifaces.end()){
            if (ifaceIt->ip == ip_header->ip_dst) {
                return;
            }
            ifaceIt++;
        }

        // Get interface
        const Interface* ip_iface = findIfaceByName(m_routingTable.lookup(ip_header->ip_dst).ifName);
        
        // Check ARP cache to see if MAC address has been mapped to destination IP
        std::shared_ptr<ArpEntry> arp_entry = m_arp.lookup(ip_header->ip_dst);
        
        if(arp_entry == nullptr) {
            // Address not in ARP cache
            // Router queues received packet and sends ARP request
            m_arp.queueRequest(ip_header->ip_dst, ip_packet, ip_iface->name);
            
            // Create and send an ARP request packet
            // Largely based on creating ARP request in arp-cache.cpp
            // Get required length of combined ethernet + arp headers
//            uint8_t req_len = sizeof(ethernet_hdr) + sizeof(arp_hdr);
            
            // Create buffer for packet
            Buffer packetBuffer((uint8_t)(sizeof(ethernet_hdr) + sizeof(arp_hdr)));
            uint8_t* req_pack = (uint8_t *)packetBuffer.data();
            
            // Get pointers to ethernet and arp headers
            ethernet_hdr* request_e_hdr = (ethernet_hdr *)req_pack;
            arp_hdr* request_a_hdr = (arp_hdr *)(req_pack + sizeof(ethernet_hdr));
            
            memcpy(request_e_hdr->ether_shost, ip_iface->addr.data(), 6);
            memcpy(request_e_hdr->ether_dhost, BroadcastEtherAddr, 6);
            request_e_hdr->ether_type = htons(ethertype_arp);
            
            // Create ARP header
            request_a_hdr->arp_hrd = htons(arp_hrd_ethernet);
            request_a_hdr->arp_pro = htons(ethertype_ip);
            request_a_hdr->arp_hln = 6;
            request_a_hdr->arp_pln = 4;
            request_a_hdr->arp_op = htons(arp_op_request);
            
            memcpy(request_a_hdr->arp_sha, ip_iface->addr.data(), 6);
            request_a_hdr->arp_sip = ip_iface->ip;
            memcpy(request_a_hdr->arp_tha, BroadcastEtherAddr, 6);
            request_a_hdr->arp_tip = ip_header->ip_dst;
            
            sendPacket(packetBuffer, ip_iface->name);
        }
        else{
            // Found valid mapping, can forward packet
            // Create ethernet header
            ethernet_hdr* ip_e_hdr = (ethernet_hdr *)ip_packet.data();
            
            // Set addresses and type for ethernet header
            memcpy(ip_e_hdr->ether_shost, ip_iface->addr.data(), 6);
            memcpy(ip_e_hdr->ether_dhost, arp_entry->mac.data(), 6);
            ip_e_hdr->ether_type = htons(ethertype_ip);
            
            sendPacket(ip_packet, ip_iface->name);
        }
    } // end handleIpPacket()
    

    void
    SimpleRouter::handleArpPacket(const Buffer& packet, const Interface* iface){
        // Get pointer to ARP header
        // TODO: use reinterpret_cast
        arp_hdr* a_hdr = (arp_hdr *)(packet.data() + sizeof(ethernet_hdr));
        
        // Get ARP operation from header
        unsigned short a_op = ntohs(a_hdr->arp_op);
        
        // Check if operation is a ARP request (defined in protocol.hpp)
        if (a_op == arp_op_request)
            handleArpRequest(a_hdr, iface);
        else if (a_op == arp_op_reply)
            handleArpReply(a_hdr, iface);
        else
            errorExit("ERROR: ARP operation is not of type request or reply");
    }
    
    void SimpleRouter::handleArpRequest(const arp_hdr* a_hdr, const Interface* iface)
    {
        std::cerr << "NOTE: Handling ARP request" << std::endl;
        
        // Check that packet has a matching target IP address and network interface ip
        if (a_hdr->arp_tip != iface->ip) {
            errorExit("ERROR: Target IP address does not match, dropping packet");
        }
        
        Buffer packetBuffer(sizeof(ethernet_hdr) + sizeof(arp_hdr));
        uint8_t* req_pack = (uint8_t *)packetBuffer.data();
        
        ethernet_hdr* reply_e_hdr = (ethernet_hdr *)req_pack;
        memcpy(reply_e_hdr->ether_dhost, &(a_hdr->arp_sha), 6);
        memcpy(reply_e_hdr->ether_shost, iface->addr.data(), 6);
        reply_e_hdr->ether_type = htons(ethertype_arp);
        
        // Create ARP header
        arp_hdr* reply_a_hdr = (arp_hdr *)(req_pack + sizeof(ethernet_hdr));
        reply_a_hdr->arp_hrd = htons(arp_hrd_ethernet);
        reply_a_hdr->arp_pro = htons(ethertype_ip);
        reply_a_hdr->arp_hln = a_hdr->arp_hln;
        reply_a_hdr->arp_pln = a_hdr->arp_pln;
        reply_a_hdr->arp_op = htons(arp_op_reply);
        
        memcpy(reply_a_hdr->arp_sha, iface->addr.data(), 6);
        reply_a_hdr->arp_sip = iface->ip;
        memcpy(reply_a_hdr->arp_tha, &(a_hdr->arp_sha), 6);
        reply_a_hdr->arp_tip = a_hdr->arp_sip;
        
        // For debugging purposes
        // print_hdrs(packetBuffer);
        
        // Send reply packet
        sendPacket(packetBuffer, iface->name);
    }
    
    void SimpleRouter::handleArpReply(const arp_hdr* a_hdr, const Interface* iface)
    {
        std::cerr << "NOTE: Handling ARP reply" << std::endl;

        Buffer a_mac(6);
        memcpy(a_mac.data(), a_hdr->arp_sha, 6);
        
        std::shared_ptr<ArpRequest> a_request = m_arp.insertArpEntry(a_mac, a_hdr->arp_sip);
        

        if (a_request != nullptr) {
            std::list<PendingPacket>::const_iterator packetIt = a_request->packets.begin();
            while(packetIt != a_request->packets.end()){
                ethernet_hdr* eth_hdr = (ethernet_hdr *) packetIt->packet.data();
                
                memcpy(eth_hdr->ether_shost, iface->addr.data(), 6);
                memcpy(eth_hdr->ether_dhost, a_hdr->arp_sha, 6);
                
                sendPacket(packetIt->packet, packetIt->iface);
                packetIt++;
            }
            // Remove pending request from arp request queue
            m_arp.removeRequest(a_request);
        }
    }
    
    //////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////
    
    // You should not need to touch the rest of this code.
    SimpleRouter::SimpleRouter()
    : m_arp(*this)
    {
    }
    
    void
    SimpleRouter::sendPacket(const Buffer& packet, const std::string& outIface)
    {
        m_pox->begin_sendPacket(packet, outIface);
    }
    
    bool
    SimpleRouter::loadRoutingTable(const std::string& rtConfig)
    {
        return m_routingTable.load(rtConfig);
    }
    
    void
    SimpleRouter::loadIfconfig(const std::string& ifconfig)
    {
        std::ifstream iff(ifconfig.c_str());
        std::string line;
        while (std::getline(iff, line)) {
            std::istringstream ifLine(line);
            std::string iface, ip;
            ifLine >> iface >> ip;
            
            in_addr ip_addr;
            if (inet_aton(ip.c_str(), &ip_addr) == 0) {
                throw std::runtime_error("Invalid IP address `" + ip + "` for interface `" + iface + "`");
            }
            
            m_ifNameToIpMap[iface] = ip_addr.s_addr;
        }
    }
    
    void
    SimpleRouter::printIfaces(std::ostream& os)
    {
        if (m_ifaces.empty()) {
            os << " Interface list empty " << std::endl;
            return;
        }
        
        for (const auto& iface : m_ifaces) {
            os << iface << "\n";
        }
        os.flush();
    }
    
    const Interface*
    SimpleRouter::findIfaceByIp(uint32_t ip) const
    {
        auto iface = std::find_if(m_ifaces.begin(), m_ifaces.end(), [ip] (const Interface& iface) {
            return iface.ip == ip;
        });
        
        if (iface == m_ifaces.end()) {
            return nullptr;
        }
        
        return &*iface;
    }
    
    const Interface*
    SimpleRouter::findIfaceByMac(const Buffer& mac) const
    {
        auto iface = std::find_if(m_ifaces.begin(), m_ifaces.end(), [mac] (const Interface& iface) {
            return iface.addr == mac;
        });
        
        if (iface == m_ifaces.end()) {
            return nullptr;
        }
        
        return &*iface;
    }
    
    const Interface*
    SimpleRouter::findIfaceByName(const std::string& name) const
    {
        auto iface = std::find_if(m_ifaces.begin(), m_ifaces.end(), [name] (const Interface& iface) {
            return iface.name == name;
        });
        
        if (iface == m_ifaces.end()) {
            return nullptr;
        }
        
        return &*iface;
    }
    
    void
    SimpleRouter::reset(const pox::Ifaces& ports)
    {
        std::cerr << "Resetting SimpleRouter with " << ports.size() << " ports" << std::endl;
        
        m_arp.clear();
        m_ifaces.clear();
        
        for (const auto& iface : ports) {
            auto ip = m_ifNameToIpMap.find(iface.name);
            if (ip == m_ifNameToIpMap.end()) {
                std::cerr << "IP_CONFIG missing information about interface `" + iface.name + "`. Skipping it" << std::endl;
                continue;
            }
            
            m_ifaces.insert(Interface(iface.name, iface.mac, ip->second));
        }
        
        printIfaces(std::cerr);
    }
    
    
} // namespace simple_router {
