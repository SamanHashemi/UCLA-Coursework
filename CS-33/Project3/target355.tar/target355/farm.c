/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_177(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_153(unsigned x)
{
    return x + 2428995912U;
}

void setval_244(unsigned *p)
{
    *p = 2425411714U;
}

unsigned getval_449()
{
    return 1589743704U;
}

void setval_392(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_233(unsigned x)
{
    return x + 3104686936U;
}

unsigned getval_258()
{
    return 2445773128U;
}

unsigned addval_379(unsigned x)
{
    return x + 3284642120U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_474(unsigned x)
{
    return x + 3523270281U;
}

unsigned getval_162()
{
    return 3281043865U;
}

void setval_327(unsigned *p)
{
    *p = 3286270280U;
}

unsigned addval_372(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_381()
{
    return 3677929881U;
}

void setval_236(unsigned *p)
{
    *p = 3229139337U;
}

unsigned getval_343()
{
    return 3269495112U;
}

unsigned getval_476()
{
    return 3281046153U;
}

void setval_241(unsigned *p)
{
    *p = 3284240894U;
}

void setval_405(unsigned *p)
{
    *p = 3380923017U;
}

unsigned addval_464(unsigned x)
{
    return x + 3523794571U;
}

unsigned getval_286()
{
    return 2430634312U;
}

unsigned addval_408(unsigned x)
{
    return x + 3675838089U;
}

unsigned getval_173()
{
    return 2497743176U;
}

void setval_414(unsigned *p)
{
    *p = 3374369289U;
}

unsigned addval_105(unsigned x)
{
    return x + 2428748168U;
}

unsigned addval_135(unsigned x)
{
    return x + 3223372169U;
}

unsigned getval_344()
{
    return 3526940297U;
}

unsigned addval_465(unsigned x)
{
    return x + 3374366985U;
}

unsigned getval_373()
{
    return 3281046185U;
}

unsigned addval_157(unsigned x)
{
    return x + 2429190405U;
}

void setval_335(unsigned *p)
{
    *p = 3284831121U;
}

unsigned addval_256(unsigned x)
{
    return x + 3224945025U;
}

unsigned addval_435(unsigned x)
{
    return x + 3281046025U;
}

void setval_312(unsigned *p)
{
    *p = 3374896777U;
}

unsigned getval_121()
{
    return 2497743176U;
}

unsigned addval_388(unsigned x)
{
    return x + 3525888649U;
}

unsigned addval_269(unsigned x)
{
    return x + 3767093455U;
}

unsigned getval_342()
{
    return 3599589562U;
}

unsigned getval_226()
{
    return 3224950409U;
}

void setval_189(unsigned *p)
{
    *p = 3767094489U;
}

void setval_303(unsigned *p)
{
    *p = 2425411213U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
