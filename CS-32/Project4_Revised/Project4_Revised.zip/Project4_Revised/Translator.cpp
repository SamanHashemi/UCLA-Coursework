#include "provided.h"
#include <string>
using namespace std;

class TranslatorImpl
{
public:
    bool pushMapping(string ciphertext, string plaintext);
    bool popMapping();
    string getTranslation(const string& ciphertext) const;
private:
    struct Node{
        MyHash<char, char> *data;
        Node* next;
    };
    
    MyHash<char, char> *m_mapTable;
    Node *top = nullptr;
    int popCount = 0;
    int pushCount = 0;
};

bool TranslatorImpl::pushMapping(string ciphertext, string plaintext)
{
    // If the two strings have different sizes then they can't be the same
    if(ciphertext.size() != plaintext.size()){
        return false;
    }
    for(int i = 0; i < ciphertext.size(); i++){
        char cipher_char = ciphertext[i]; // cur ciphertext character
        char plain_char = plaintext[i]; // cur plaintext character
        
        // If either char is not a letter
        if(!isalpha(cipher_char) || !isalpha(plain_char) ){
            return false;
        }
        
        // If the value mapped to is not a '?' or the table Value doesn't match the plaintext
        if(*(m_mapTable->find(toupper(cipher_char))) != '?' && toupper(*(m_mapTable->find(toupper(cipher_char)))) != toupper(plain_char)){
            return false; //TODO: Check conditionals (below too)
        }
        
        // If the char isn't in the table
        if(m_mapTable->find(cipher_char) == nullptr){
            
            pushCount++; // Keep track of the number of times this function is called
            m_mapTable->associate(cipher_char, plain_char); // add it!
            
            // Create a new mapping of updated values
            MyHash<char, char> *curTable = nullptr;
            for(int i = 0; i < 26; i++){
                curTable->associate('A'+i, *m_mapTable->find('A'+i));
            }
            
            // Create a node that holds the new map
            Node* newMap = nullptr;
            newMap->data = curTable;
            
            // If stack is empty
            if(top == nullptr){
                top = newMap;
                top->next = nullptr;
            }
            else{ // Not empty
                Node* curNode = nullptr;
                curNode->data = curTable;
                curNode->next = top->next;
                top = curNode;
                
            }
        }
    }
    return true;
}

bool TranslatorImpl::popMapping()
{
    if(popCount == pushCount){
        return false;
    }
    else{
        // Change the mapTable to the most recent
        m_mapTable = top->data;
        Node* temp = top;
        top = top->next;
        delete temp;
    }
    popCount++;
    return true;  // This compiles, but may not be correct
}

string TranslatorImpl::getTranslation(const string& ciphertext) const
{
    string returnString = "";
    for(int i = 0; i < ciphertext.size(); i++){
        char curLetter = (*m_mapTable->find(ciphertext[i]));
        if(islower(ciphertext[i])){
            returnString += tolower(curLetter);
        }
        else if(isupper(ciphertext[i])){
            returnString += toupper(ciphertext[i]);
        }
        else{
            returnString += ciphertext[i];
        }
    }
    return returnString;
}

//******************** Translator functions ************************************

// These functions simply delegate to TranslatorImpl's functions.
// You probably don't want to change any of this code.

Translator::Translator()
{
    m_impl = new TranslatorImpl;
}

Translator::~Translator()
{
    delete m_impl;
}

bool Translator::pushMapping(string ciphertext, string plaintext)
{
    return m_impl->pushMapping(ciphertext, plaintext);
}

bool Translator::popMapping()
{
    return m_impl->popMapping();
}

string Translator::getTranslation(const string& ciphertext) const
{
    return m_impl->getTranslation(ciphertext);
}
