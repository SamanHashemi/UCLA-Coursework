#include "provided.h"
#include <string>
#include <vector>
#include <functional>
#include <iostream>
#include <fstream>

using namespace std;

class WordListImpl
{
public:
    bool loadWordList(string filename);
    bool contains(string word) const;
    vector<string> findCandidates(string cipherWord, string currTranslation) const;
private:
    MyHash<std::string, std::vector<std::string>> wordList;
//    Tokenizer t;
    std::string keyUp(std::string s) const;
};

bool WordListImpl::loadWordList(string filename) // Should work 70% sure
{
    // TODO: Check if the file is opened correctly
    wordList.reset();
    bool addToList = true;
    std::string curLine;
    std::string upperString = "";
    std::vector<std::string> curWords;
    ifstream infile(filename);
    if (!infile)
        return false;
    while(std::getline(infile, curLine)){
        for(int i = 0; i < curLine.size(); i++){
            // If the current chacter is not a letter or apostrophe
            if(!isalpha(curLine[i]) && curLine[i] != 39){
                addToList = false; // Dont add anything
                break; // move on to the next line
            }
            upperString += toupper(curLine[i]); // add the uppercase letter to string
        }
        if(addToList){ // if line was valid
            curWords = *wordList.find(keyUp(upperString)); // Get the string vector
            curWords.push_back(upperString); // Put string in the vector
            wordList.associate(keyUp(upperString), curWords); // Re-associate
        }
        upperString = "";
        addToList = true;
    }
    return true;
}

bool WordListImpl::contains(string word) const // Should work 90% sure
{
    if((wordList.find(keyUp(word))) == nullptr){
        return false;
    }
    std::vector<std::string> words = *(wordList.find(keyUp(word)));
    for(int i = 0; i < words.size(); i++){
        if(words[i].compare(word) == 0){
            return true;
        }
    }
    return false;
}

vector<string> WordListImpl::findCandidates(string cipherWord, string currTranslation) const
{
    std::vector<std::string> candiates;
    if(wordList.find((keyUp(cipherWord))) == nullptr) // If the pointer is null then there is nothing corresponding w this string
        return candiates;
    int numMatching = 0; // The number of the matching values
    std::vector<std::string> possibleWords = *wordList.find((keyUp(cipherWord)));
    
    for(int i = 0; i < possibleWords.size(); i++){
        std::string compareWord = possibleWords[i];
        if(compareWord.size() == currTranslation.size()){
            for(int i = 0; i < possibleWords.size(); i++){ 
                if(toupper(compareWord[i]) == toupper(currTranslation[i]) || currTranslation[i] == '?'){
                    numMatching++;
                    break;
                }
                if(numMatching == compareWord.size()){
                    candiates.push_back(compareWord);
                }
            }
        }
        numMatching = 0;
    }
    return candiates;
}

std::string WordListImpl::keyUp(std::string s) const{

    MyHash<char, char> list;
    std::string tempString = "";
    for(int i = 0; i < s.size(); i++){
        if(list.find(toupper(s[i])) == nullptr){
            list.associate(i + 'A', toupper(s[i]));
            tempString += (char)(i + 'A');
        }
        else{
            tempString += (list.find(toupper(s[i])));
        }
    }
    return tempString;
//    // Create the counter and the new array to hold the repeat values
//    int tempIntHolder[s.size()];
//    int counter = 1;
//
//    // Set int array to 0
//    for(int i = 0; i < s.size(); i++){
//        tempIntHolder[i] = 0;
//    }
//
//    // Go through the string and add the correct numbers to the array
//    for(int i = 0; i < s.size(); i++){
//        for(int j = i; j < s.size(); j++){
//            if(s[i] == s[j] && i != j && tempIntHolder[j] == 0){
//                tempIntHolder[j] = counter;
//            }
//        }
//        tempIntHolder[i] = counter++;
//    }
//    s = " "; // make "+=" not "=" when this function returns a string
//    // Add the integers to the string
//    for(int i = 0; i < s.size(); i++){
//        s += std::to_string(tempIntHolder[i]);
//    }
    
}

//***** hash functions for string, int, and char *****

unsigned int hash(const std::string& s)
{
    return std::hash<std::string>()(s);
}

unsigned int hash(const int& i)
{
    return std::hash<int>()(i);
}

unsigned int hash(const char& c)
{
    return std::hash<char>()(c);
}

//******************** WordList functions ************************************

// These functions simply delegate to WordListImpl's functions.
// You probably don't want to change any of this code.

WordList::WordList()
{
    m_impl = new WordListImpl;
}

WordList::~WordList()
{
    delete m_impl;
}

bool WordList::loadWordList(string filename)
{
    return m_impl->loadWordList(filename);
}

bool WordList::contains(string word) const
{
    return m_impl->contains(word);
}

vector<string> WordList::findCandidates(string cipherWord, string currTranslation) const
{
   return m_impl->findCandidates(cipherWord, currTranslation);
}
