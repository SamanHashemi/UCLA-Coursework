// MyHash.h

// Skeleton for the MyHash class template.  You must implement the first seven
// member functions; we have implemented the eighth.

#include <stdio.h>
#include <string>
#include <functional>
#include <iostream>

template<typename KeyType, typename ValueType>
class MyHash
{
public:
    MyHash(double maxLoadFactor = 0.5);
    ~MyHash();
    void reset();
    void associate(const KeyType& key, const ValueType& value);
    int getNumItems() const;
    double getLoadFactor() const;

      // for a map that can't be modified, return a pointer to const ValueType
    const ValueType* find(const KeyType& key) const;

      // for a modifiable map, return a pointer to modifiable ValueType
    ValueType* find(const KeyType& key)
    {
        return const_cast<ValueType*>(const_cast<const MyHash*>(this)->find(key));
    }

      // C++11 syntax for preventing copying and assignment
    MyHash(const MyHash&) = delete;
    MyHash& operator=(const MyHash&) = delete;

private:
    int m_numElements = 0; // the current number of elements in the hash table
    int m_numBuckets = 100;
    double m_curLF = 0; // the current load factor
    double m_maxLF; // the max load factor until you must reallcat
    
    unsigned int getBucketNumber(const KeyType& k) const{
        unsigned int hash(const KeyType& k);
        return hash(k)%m_numBuckets;
    }
    
    // The Bucket
    struct Node{
        KeyType key;
        ValueType value;
        Node *next;
    };
    
    Node **m_table = new Node*[m_numBuckets];
};


//Testing: Check to see if the default (0.5) load factor is being used when nothing is passed to construcor
template <typename KeyType, typename ValueType>
MyHash<KeyType,ValueType>::MyHash(double maxLoadFactor) : m_maxLF(maxLoadFactor){ // NOTE: Should be okay, 99% certain
    for(int i = 0; i < m_numBuckets; i++){
        m_table[i] = nullptr;
    }
    if(m_maxLF <= 0){ // prevent the max load factor from being 0 or negative
        m_maxLF = 0.5;
    }
    else if(m_maxLF > 2){ // prevent the max load factor from exceeding 2
        m_maxLF = 2.0;
    }
}


// Deconstruct the hash table and remove all values
template <typename KeyType, typename ValueType>
MyHash<KeyType,ValueType>::~MyHash(){ // NOTE: Should be okay, 99% certain (minus the possible creation of "value" to ptr
    // Delete all buckets
    for(int i = 0; i < m_numBuckets; i++){
        Node *curNode = m_table[i]; // First node of the bucket
        // Delete all nodes and their corresponding grossness
        while(curNode != nullptr){
            Node *temp = curNode;
            // TODO: Check deallocation here if you decide to make "value" (in node) a pointer
            curNode = curNode->next;
            delete temp;
        }
    }
    delete [] m_table; // TODO: Check deallocation here
}

// Reset the hash table with new values
template <typename KeyType, typename ValueType>
void MyHash<KeyType, ValueType>::reset(){ // NOTE: Should be okay 90% certain (minus the possible creation of "value" to ptr
    // Delete all buckets
    for(int i = 0; i < m_numBuckets; i++){
        Node *curNode = m_table[i];
        while(curNode != nullptr){
            Node *temp = curNode;
            // TODO: Check deallocation here if you decide to make "value" (in node) a pointer
            curNode = curNode->next;
            delete temp;
        }
    }
    delete [] m_table; // TODO: Check deallocation here
    m_numElements = 0;
    m_curLF = 0;
    *m_table = new Node[100];
}

// Add a new value to the hash table
template <typename KeyType, typename ValueType>
void MyHash<KeyType, ValueType>::associate(const KeyType &key, const ValueType &value){ // NOTE: Not v sure probs like 70% certantiy
    unsigned int hash(const KeyType& k);
    
    /////////////////////////////////
    // IF LOAD FACTOR WAS EXCEEDED //
    ////////////////////////////////
    ValueType* val_pointer = find(key);
    if(val_pointer == nullptr){
        m_numElements++;
        if(getLoadFactor() > m_maxLF){
            Node **tempTable = new Node*[m_numBuckets*2]; // Create a new map that holds 2x the number of nodes
            
            // Initilize the new map to nullptrs
            for(int i = 0; i < 2*m_numBuckets; i++)
                tempTable[i] = nullptr;
            
            // Go through the original map
            for(int i = 0; i < m_numBuckets; i++){
                
                Node* curNode = m_table[i]; // Old array
                
                while(curNode != nullptr){
                    // Create a new node pointer with the values from the previous list
                    Node* bucketPtr = tempTable[hash(key) % (m_numBuckets*2)];
                    Node* data = new Node;
                    data->key = curNode->key;
                    data->value = curNode->value;
                    data->next = bucketPtr;
                    tempTable[hash(key) % (m_numBuckets*2)] = data;
                    
                    curNode = curNode->next;
                }
            }
        
            Node* tempNew = tempTable[hash(key) % (m_numBuckets*2)];
            Node* data = new Node;
            data->key = key;
            data->value = value;
            data->next = tempNew;
            tempTable[hash(key) % (m_numBuckets*2)] = data;
            
            // Delete all of the previous stuff here
            for(int i = 0; i < m_numBuckets; i++){
                Node* curOld = m_table[i];
                while(curOld != nullptr){
                    Node* temp = curOld;
                    curOld = curOld->next;
                    delete temp;
                }
            }
            m_numBuckets *= 2;
            delete [] tempTable;
            m_table = tempTable;
        }
        else{
            Node* curNode = m_table[getBucketNumber(key)];
            Node* data = new Node;
            
            data->key = key;
            data->value = value;
            data->next = curNode;
            
            m_table[getBucketNumber(key)] = data;
        }
    }
    else{
        *val_pointer = value;
    }
}
//        bool keyExists = false; // if a value is alread in the array
//        Node *curNode = m_table[getBucketNumber(key)];
//
//        //Create a new node
//        Node* nodeToAdd = new Node;
//        nodeToAdd->key = key;
//        nodeToAdd->value = value;
//        nodeToAdd->next = nullptr;
//
//        // If the bucket is empty and contains no node
//        if(curNode == nullptr){
//            // Create the new node from the value and key
//            m_table[getBucketNumber(key)] = nodeToAdd;
//            m_numElements++;
//        }
//        else{
//            // Get the starting node and go through the LL to check for duplicate strings
//            while(curNode->next != nullptr){
//                if(curNode->key == key){ // if the node in the list and the key to add are the same
//                    /// TODO: May need to change this to "delete [] curNode->value"
//                    curNode->value = value; // the value of the node must be changed to the value being passes
//                    keyExists = true; // there is a key duplicate
//                    break;
//                }
//                curNode = curNode->next;
//            }
//            if(!keyExists){ // there were no duplicates
//                curNode->next = nodeToAdd;
//                m_numElements++;
//            }
//        }
//    }

// Find the corresponding bucket to

//TODO: May need to make this "const" spec and the provided skeleton differ
template <typename KeyType, typename ValueType>
const ValueType* MyHash<KeyType, ValueType>::find(const KeyType &key) const{ // NOTE: Should be okay, 99% certain
    Node *curNode = m_table[getBucketNumber(key)];
    while(curNode != nullptr){
        if(curNode->key == key){
            return &(curNode->value);
        }
        curNode = curNode->next;
    }
    return nullptr;
}

// Return the number of elements in the list
template <typename KeyType, typename ValueType>
int MyHash<KeyType, ValueType>::getNumItems() const{ // NOTE: Is okay, 100% certain
    return m_numElements;
}

// Return the current load factor
template <typename KeyType, typename ValueType>
double MyHash<KeyType, ValueType>::getLoadFactor() const{ // NOTE: Is okay, 100% certain
    return (double)(((double)m_numElements)/((double)m_numBuckets));
}
