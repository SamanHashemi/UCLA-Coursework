"""
Author      : Yi-Chieh Wu, Sriram Sankararaman
Description : Famous Faces
"""

# python libraries
import collections
import time
# numpy libraries
import numpy as np

# matplotlib libraries
import matplotlib.pyplot as plt

# libraries specific to project
import util
from util import *
from cluster import *

######################################################################
# helper functions
######################################################################

def build_face_image_points(X, y) :
    """
    Translate images to (labeled) points.
    
    Parameters
    --------------------
        X     -- numpy array of shape (n,d), features (each row is one image)
        y     -- numpy array of shape (n,), targets
    
    Returns
    --------------------
        point -- list of Points, dataset (one point for each image)
    """
    
    n,d = X.shape
    
    images = collections.defaultdict(list) # key = class, val = list of images with this class
    for i in range(n) :
        images[y[i]].append(X[i,:])

    points = []
    for face in images :
        count = 0
        for im in images[face] :
            points.append(Point(str(face) + '_' + str(count), face, im))
            count += 1

    return points


def plot_clusters(clusters, title, average) :
    """
    Plot clusters along with average points of each cluster.

    Parameters
    --------------------
        clusters -- ClusterSet, clusters to plot
        title    -- string, plot title
        average  -- method of ClusterSet
                    determines how to calculate average of points in cluster
                    allowable: ClusterSet.centroids, ClusterSet.medoids
    """

    plt.figure()
    np.random.seed(20)
    label = 0
    colors = {}
    centroids = average(clusters)
    for c in centroids :
        coord = c.attrs
        plt.plot(coord[0],coord[1], 'ok', markersize=12)
    for cluster in clusters.members :
        label += 1
        colors[label] = np.random.rand(3,)
        for point in cluster.points :
            coord = point.attrs
            plt.plot(coord[0], coord[1], 'o', color=colors[label])
    plt.title(title)
    plt.show()


def generate_points_2d(N, seed=1234) :
    """
    Generate toy dataset of 3 clusters each with N points.

    Parameters
    --------------------
        N      -- int, number of points to generate per cluster
        seed   -- random seed

    Returns
    --------------------
        points -- list of Points, dataset
    """
    np.random.seed(seed)

    mu = [[0,0.5], [1,1], [2,0.5]]
    sigma = [[0.1,0.1], [0.25,0.25], [0.15,0.15]]

    label = 0
    points = []
    for m,s in zip(mu, sigma) :
        label += 1
        for i in range(N) :
            x = util.random_sample_2d(m, s)
            points.append(Point(str(label)+'_'+str(i), label, x))

    return points


######################################################################
# k-means and k-medoids
######################################################################

def random_init(points, k) :
    """
    Randomly select k unique elements from points to be initial cluster centers.

    Parameters
    --------------------
        points         -- list of Points, dataset
        k              -- int, number of clusters

    Returns
    --------------------
        initial_points -- list of k Points, initial cluster centers
    """
    ### ========== TODO : START ========== ###
    # part 2c: implement (hint: use np.random.choice)
    if k >= len(points):
        return None
    initial_points = np.random.choice(points, k, replace=False)
    return initial_points
    ### ========== TODO : END ========== ###


def cheat_init(points):
    """
    Initialize clusters by cheating!

    Details
    - Let k be number of unique labels in dataset.
    - Group points into k clusters based on label (i.e. class) information.
    - Return medoid of each cluster as initial centers.

    Parameters
    --------------------
        points         -- list of Points, dataset

    Returns
    --------------------
        initial_points -- list of k Points, initial cluster centers
    """
    ### ========== TODO : START ========== ###
    # part 2f: implement
    label_to_points = {}
    for p in points:
        if p.label in label_to_points:
            label_to_points[p.label].append(p)
        else:
            label_to_points[p.label] = [p]
    return [Cluster(v).medoid() for _, v in label_to_points.items()]
    ### ========== TODO : END ========== ###


def kAverages(points, k, average, init='random', plot=False):
    """
    Cluster points into k clusters using variations of k-means algorithm.

    Parameters
    --------------------
        points  -- list of Points, dataset
        k       -- int, number of clusters
        average -- method of ClusterSet
                   determines how to calculate average of points in cluster
                   allowable: ClusterSet.centroids, ClusterSet.medoids
        init    -- string, method of initialization
                   allowable:
                       'cheat'  -- use cheat_init to initialize clusters
                       'random' -- use random_init to initialize clusters
        plot    -- bool, True to plot clusters with corresponding averages
                         for each iteration of algorithm

    Returns
    --------------------
        k_clusters -- ClusterSet, k clusters
    """

    ### ========== TODO : START ========== ###
    # part 2c: implement
    # Hints:
    #   (1) On each iteration, keep track of the new cluster assignments
    #       in a separate data structure. Then use these assignments to create
    #       a new ClusterSet object and update the centroids.
    #   (2) Repeat until the clustering no longer changes.
    #   (3) To plot, use plot_clusters(...).

    init_points = None
    if init == 'random':
        init_points = random_init(points, k)
    elif init == 'cheat':
        init_points = cheat_init(points)
    else:
        return None

    cluster_centers = init_points
    prev_clusterset = None
    epochs = 0

    while True:
        # update step for clusters
        clusterset = ClusterSet([Cluster(v) for _, v in cluster_assignment(cluster_centers, points).items()])

        # if objective function stays the same, return
        if prev_clusterset != None and clusterset.equivalent(prev_clusterset):
            return clusterset

        if plot:
            plot_clusters(clusterset,
                    'Iteration {} using {} init'.format(epochs, init), average)
        # update step for centers
        prev_clusterset = clusterset
        if average == ClusterSet.centroids:
            cluster_centers = clusterset.centroids()
        elif average == ClusterSet.medoids:
            cluster_centers = clusterset.medoids()
        else:
            return None
        epochs += 1

    k_clusters = ClusterSet()
    return k_clusters
    ### ========== TODO : END ========== ###

def cluster_assignment(clusters, points):
    assignments = {}
    for p in points:
        min_dist, i = np.Inf, -1
        for idx, c in enumerate(clusters):
            d = p.distance(c)
            if d < min_dist:
                i = idx
                min_dist = d
        if i not in assignments:
            assignments[i] = []
        assignments[i].append(p)
    return assignments


def kMeans(points, k, init='random', plot=False):
    """
    Cluster points in k clusters using k-centroids clustering.
    """
    return kAverages(points, k, ClusterSet.centroids, init=init, plot=plot)

def kMedoids(points, k, init='random', plot=False) :
    """
    Cluster points in k clusters using k-medoids clustering.
    See kMeans(...).
    """
    return kAverages(points, k, ClusterSet.medoids, init=init, plot=plot)


######################################################################
# main
######################################################################

def main() :
    ### ========== TODO : START ========== ###
    # part 1: explore LFW data set

    ### ========== TODO : END ========== ###



    ### ========== TODO : START ========== ###
    # part 2d-2f: cluster toy dataset
    np.random.seed(1234)
    points = generate_points_2d(40)

    # clusterset = kMeans(points, 4, init='random', plot=True)
    # print ("kMeans, random: %f" % clusterset.score())
    # clusterset = kMedoids(points, 4, init='random', plot=True)
    # print ("kMedoids, random: %f" % clusterset.score())
    # clusterset = kMeans(points, 4, init='cheat', plot=True)
    # print ("kMeans, cheat: %f" % clusterset.score())
    # clusterset = kMedoids(points, 4, init='cheat', plot=True)
    # print ("kMedoids, cheat: %f" % clusterset.score())

    ### ========== TODO : END ========== ###



    ### ========== TODO : START ========== ###
    # part 3a: cluster faces
    X, y = get_lfw_data()
    X1, y1 = util.limit_pics(X, y, [4, 6, 13, 16], 40)
    points = build_face_image_points(X1, y1)
    np.random.seed(1234)
    kmeans_list = []
    kmedoid_list = []
    kmeans_time = []
    kmed_time = []
    for i in range(10):
        meantime_start = time.time()
        clusterset = kMeans(points, 4, init='random', plot=False)
        meantime_end = time.time()
        kmeans_time.append(meantime_end - meantime_start)
        kmeans_list.append(clusterset.score())
        medtime_start = time.time()
        clusterset = kMedoids(points, 4, init='random', plot=False)
        medtime_end = time.time()
        kmed_time.append(medtime_end-medtime_start)
        kmedoid_list.append(clusterset.score())

    print("kmeans max: " + str(max(kmeans_list)))
    print("kmeans min: " + str(min(kmeans_list)))
    print("kmeans ave: " + str((sum(kmeans_list)/len(kmeans_list))))

    print()

    print("kmed max: " + str(max(kmedoid_list)))
    print("kmed min: " + str(min(kmedoid_list)))
    print("kmed ave: " + str((sum(kmedoid_list) / len(kmedoid_list))))

    print()

    print("kmeantime max: " + str(max(kmeans_time)))
    print("kmeantime min: " + str(min(kmeans_time)))
    print("kmeantime ave: " + str(sum(kmeans_time) / len(kmeans_time)))

    print()

    print("kmedtime max: " + str(max(kmed_time)))
    print("kmedtime min: " + str(min(kmed_time)))
    print("kmedtime ave: " + str(sum(kmed_time)/len(kmed_time)))

    # part 3b: explore effect of lower-dimensional representations on clustering performance
    np.random.seed(1234)
    X2, y2 = util.limit_pics(X, y, [4, 13], 40)
    U2, mu2 = PCA(X)

    kmed_l_and_score = {}
    kmean_l_and_score = {}
    for l in range(1, 42):
        Z2, Ul2 = apply_PCA_from_Eig(X2, U2, l, mu2)
        X_rec = reconstruct_from_PCA(Z2, Ul2, mu2)
        points = build_face_image_points(X_rec, y2)
        clusterset = kMedoids(points, 2, init='cheat', plot=False)
        kmed_l_and_score[l] = clusterset.score()
        clusterset = kMeans(points, 2, init='cheat', plot=False)
        kmean_l_and_score[l] = clusterset.score()

    kmean_graph = kmean_l_and_score.items()
    kmed_graph = kmed_l_and_score.items()
    x_med, y_med = zip(*kmed_graph)
    x_mean, y_mean = zip(*kmean_graph)
    plt.plot(x_med, y_med, label="kmed")
    plt.plot(x_mean, y_mean, label="kmean")
    plt.legend()
    plt.ylabel("Score")
    plt.xlabel("# Components")
    plt.show()

    # part 3c: determine ``most discriminative'' and ``least discriminative'' pairs of images
    np.random.seed(1234)
    min_score = 1
    min_tuple = None
    max_score = -1
    max_tuple = None
    for i in range(19):
        for j in range(i, 19):
            if i == j:
                continue
            X_temp, y_temp = util.limit_pics(X, y, [i, j], 40)
            points = build_face_image_points(X_temp, y_temp)
            score = kMedoids(points, 2, init='cheat').score()
            if score < min_score:
                min_score = score
                min_tuple = (i, j)
            if score > max_score:
                max_score = score
                max_tuple = (i, j)

    plot_representative_images(X, y, [max_tuple[0], max_tuple[1]], title='Least Similar')
    plot_representative_images(X, y, [min_tuple[0], min_tuple[1]], title='Most Similar')
    print(min_tuple[0])
    print(min_tuple[1])

    ### ========== TODO : END ========== ###


if __name__ == "__main__" :
    main()
